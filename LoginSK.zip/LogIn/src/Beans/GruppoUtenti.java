package Beans;

import java.time.Duration;
import java.util.*;

public class GruppoUtenti {
	
	
	private String id;
	private Set<User> utenti;
	private Boolean pwdChange;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Set<User> getUtenti() {
		return utenti;
	}
	public void setUtenti(Set<User> utenti) {
		this.utenti = utenti;
	}
	public GruppoUtenti() {
		this.id ="";
		this.utenti = new HashSet<User>();
		this.pwdChange=false;
	}
	
	public boolean addUserToGroup(User u)
	{
		return this.utenti.add(u);
	}
	public Boolean getPwdChange() {
		return pwdChange;
	}
	public void setPwdChange(Boolean pwdChange) {
		this.pwdChange = pwdChange;
	}
	
	
}
