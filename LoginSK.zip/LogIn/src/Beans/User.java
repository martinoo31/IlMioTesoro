package Beans;

import java.util.Date;

import javax.servlet.http.HttpSession;

public class User {
	
	private String userName;
	private String pwd;
	private String groupId;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public User() {
		this.groupId = "";
		this.userName = "";
		this.pwd = "";
	}
}
