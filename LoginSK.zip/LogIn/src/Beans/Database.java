package Beans;

import java.util.*;

public class Database{
	private Map<String,GruppoUtenti> gruppi;
	private Map<String,User> 		 utenti;
	
	
	
	
	public Database() {
		super();
		this.gruppi = new TreeMap<String,GruppoUtenti>();
		this.utenti = new TreeMap<String,User>();
	}
	
	public void popola() {
		
		
		//Gruppo1 ----------------------------------
		GruppoUtenti g1 = new GruppoUtenti();
		g1.setId("g1");
		this.addGruppo(g1);
		
		User j=new User();
		j.setUserName("Jordan");
		j.setPwd("jordan");
		j.setGroupId("g1");
		this.addUser(j);
		
		User g=new User();
		g.setUserName("Gian");
		g.setPwd("gian");
		g.setGroupId("g1");
		this.addUser(g);
		
		User m=new User();
		m.setUserName("Mart");
		m.setPwd("mart");
		m.setGroupId("g1");
		this.addUser(m);
		
		
		//Gruppo2 ----------------------------------
		GruppoUtenti g2 = new GruppoUtenti();
		g2.setId("g2");
		this.addGruppo(g2);
		
		User c=new User();
		c.setUserName("Chicco");
		c.setPwd("chicco");
		c.setGroupId("g2");
		this.addUser(c);
		
		User t=new User();
		t.setUserName("Toby");
		t.setPwd("toby");
		t.setGroupId("g2");
		this.addUser(t);
		
		User s=new User();
		s.setUserName("Samu");
		s.setPwd("samu");
		s.setGroupId("g2");
		this.addUser(s);
		
		//Gruppo3 -----------------------------------		
		GruppoUtenti g3= new GruppoUtenti();
		g3.setId("g3");
		this.addGruppo(g3);
		
		//Admin ------------------------------------
		User admin = new User();
		admin.setUserName("Admin");
		admin.setPwd("admin");
		admin.setGroupId(null);
		this.addUser(admin);
	}
	public Map<String, GruppoUtenti> getGruppi() {
		return gruppi;
	}
	public void setGruppi(Map<String, GruppoUtenti> gruppi) {
		this.gruppi = gruppi;
	}
	public Map<String, User> getUtenti() {
		return utenti;
	}
	public void setUtenti(Map<String, User> utenti) {
		this.utenti = utenti;
	}
	
	public User getUser(String username) {
		return utenti.get(username);
	}
	
	public GruppoUtenti getGruppo(String nomegruppo) {
		return gruppi.get(nomegruppo);
	}
	
	public void addUser(User user) {
		this.utenti.put(user.getUserName(), user);
		if(user.getGroupId()!=null) {
			this.gruppi.get(user.getGroupId()).addUserToGroup(user);
		}
	}
	
	public void addGruppo(GruppoUtenti gruppo) {
		this.gruppi.put(gruppo.getId(), gruppo);
	}
	
	

}
