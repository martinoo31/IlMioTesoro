package Servlet;

import java.io.IOException;
import java.util.Map;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import Beans.Database;
import Beans.GruppoUtenti;
import Beans.User;

public class LogIn extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private Gson g;

	@SuppressWarnings("deprecation")
	@Override
	public void init(ServletConfig conf) throws ServletException {
		super.init(conf);
		g = new Gson();
		Database db = new Database();
		db.popola();

		this.getServletContext().setAttribute("db", db);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Database db = (Database) this.getServletContext().getAttribute("db");
		Map<String, User> utentiRegistrati = db.getUtenti();
		Map<String, GruppoUtenti> gruppi = db.getGruppi();
		
		
		String jsonPayload = request.getReader().readLine();
		//System.out.println(jsonPayload);
		User userJSON = g.fromJson(jsonPayload, User.class);
		
		String group = userJSON.getGroupId();
		String name = userJSON.getUserName();
		String pwd = userJSON.getPwd();
		
		
		/*LOGIN FORM
		String group = request.getParameter("gruppo");
		String name = request.getParameter("userName");
		String pwd = request.getParameter("pwd");*/
		User utente = utentiRegistrati.get(name);
		HttpSession session = request.getSession();
		if (group == null) {

			if (utente == null) {
				// utente non registrato

				RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
				rd.forward(request, response);
				return;
			}

			if (utente.getUserName().equals("Admin")) {
				// admin
				if (utente.getPwd().equals(pwd)) {
					session.setAttribute("db", db);
					response.sendRedirect("admin.jsp");
					return;
				} else {
					//admin pwd errata
					RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
					rd.forward(request, response);
				}
				return;
			}

			if (utente.getPwd().compareTo(pwd) != 0) {
				// pwd errata

				RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
				rd.forward(request, response);
				return;
			}
			

			// Login utente corretto
			System.out.println("Ciao");
			session.setAttribute("user", utente);
			response.sendRedirect("applicazione.jsp");
			return;
			
		} else {
			// Registazione utente --------------------------------------
			if (utente != null || name == null || pwd == null) {
				//esiste già un utente con questo username, lo username è nullo, la pwd è nullo
				RequestDispatcher rd = getServletContext().getRequestDispatcher("/registrazione.jsp");
				rd.forward(request, response);
				return;
			} else {
				GruppoUtenti gruppo = gruppi.get(group);
				if (gruppo == null) {
					RequestDispatcher rd = getServletContext().getRequestDispatcher("/registrazione.jsp");
					rd.forward(request, response);
					return;
				}
				User temp = new User();
				temp.setUserName(name);
				temp.setGroupId(group);
				temp.setPwd(request.getParameter("pwd"));
				gruppo.addUserToGroup(utente);
				session.setAttribute("user", temp);
				response.sendRedirect("applicazione.jsp");

			}
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
